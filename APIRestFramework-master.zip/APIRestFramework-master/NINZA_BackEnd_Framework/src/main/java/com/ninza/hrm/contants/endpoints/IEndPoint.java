package com.ninza.hrm.contants.endpoints;

public interface IEndPoint {
	
	public String ADDProj = "/addProject";
	public String ADDEmp = "/employees";


}
